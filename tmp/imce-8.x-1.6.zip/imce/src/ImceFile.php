<?php

namespace Drupal\imce;

/**
 * Imce File.
 */
class ImceFile extends ImceItem {

  /**
   * {@inheritdoc}
   */
  public $type = 'file';
}